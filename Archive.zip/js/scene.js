Physijs.scripts.worker = 'js/physijs_worker.js'
Physijs.scripts.ammo = 'ammo.js'

let sceneWidth
let sceneHeight
let camera
let scene
let renderer
let dom
let hero
let sun
let ground
let orbitControl
let physics

init()
function init() {
	// set up the scene
	createScene()

	//call game loop
	update()
}

function createScene() {
	scene = new Physijs.Scene()
	scene.setGravity(new THREE.Vector3(0, -10, 0))
	scene.fog = new THREE.FogExp2(0xf0fff0, 0.04)
	camera = new THREE.PerspectiveCamera(
		60,
		window.innerWidth / window.innerHeight,
		0.1,
		1000
	)
	renderer = new THREE.WebGLRenderer({ alpha: true })

	renderer.shadowMap.enabled = true
	renderer.shadowMap.type = THREE.PCFSoftShadowMap

	renderer.setSize(window.innerWidth, window.innerHeight)
	document.body.appendChild(renderer.domElement)

	const heroGeometry = new THREE.BoxGeometry(1, 2, 1)
	const heroMaterial = new THREE.MeshBasicMaterial({ color: 0x883333 })
	console.log(heroGeometry)
	hero = new Physijs.BoxMesh(heroGeometry, heroMaterial)
	hero.castShadow = true
	hero.receiveShadow = false
	hero.position.y = 1
	hero.rotation.x = 2
	scene.add(hero)

	const planeGeometry = new THREE.PlaneGeometry(10, 200, 4, 4)
	const planeMaterial = new THREE.MeshStandardMaterial({ color: 0x00ff00 })
	ground = new Physijs.Mesh(planeGeometry, planeMaterial)
	ground.receiveShadow = true
	ground.castShadow = false
	ground.rotation.x = -Math.PI / 3
	scene.add(ground)

	camera.position.z = 6
	camera.position.x = 5
	camera.rotation.y = (60 * Math.PI) / 180

	sun = new THREE.DirectionalLight(0xffffff, 0.8)
	sun.position.set(0, 2, 1)
	sun.castShadow = true
	scene.add(sun)
	//Set up shadow properties for the sun light
	sun.shadow.mapSize.width = 256
	sun.shadow.mapSize.height = 256
	sun.shadow.camera.near = 0.5
	sun.shadow.camera.far = 50

	orbitControl = new THREE.OrbitControls(camera, renderer.domElement) //helper to rotate around in scene
	orbitControl.update()
	orbitControl.addEventListener('change', render)
	orbitControl.enableZoom = false

	// var helper = new THREE.CameraHelper(sun.shadow.camera)
	// scene.add(helper) // enable to see the light cone

	window.addEventListener('resize', onWindowResize, false) //resize callback
}

function update() {
	render()
	requestAnimationFrame(update) //request next update
}
function render() {
	scene.simulate()
	renderer.render(scene, camera) //draw
}
function onWindowResize() {
	//resize & align
	sceneHeight = window.innerHeight
	sceneWidth = window.innerWidth
	renderer.setSize(sceneWidth, sceneHeight)
	camera.aspect = sceneWidth / sceneHeight
	camera.updateProjectionMatrix()
}

// function animate() {
// 	requestAnimationFrame(animate)
// 	renderer.render(scene, camera)
// }
// animate()
